import json
from datetime import datetime
import pytz

# خواندن لینک‌ها
with open('subscriptions.json', 'r') as f:
    links = json.load(f)

valid_links = []
now = datetime.now(pytz.utc)

# فیلتر کردن لینک‌های معتبر
for link in links:
    expire_time = datetime.fromisoformat(link['expires']).astimezone(pytz.utc)
    if expire_time > now:
        valid_links.append(link)

# ذخیره لینک‌های معتبر در فایل
with open('subscriptions.json', 'w') as f:
    json.dump(valid_links, f, indent=2)

# ساخت HTML
with open('index.html', 'w') as f:
    f.write("""<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>Subscription Links</title>
    <style>
        body { font-family: sans-serif; background: #f0f4f8; padding: 2em; }
        h1 { text-align: center; color: #333; }
        .link { padding: 1em; background: #e0ffe0; margin: 1em 0; border-radius: 8px; }
        .expired { background: #ffd0d0; text-decoration: line-through; opacity: 0.6; }
        .meta { font-size: 0.9em; color: #555; margin-top: 0.3em; }
    </style>
</head>
<body>
<h1>Subscription Links</h1>
""")
    for link in links:
        expire_time = datetime.fromisoformat(link['expires']).astimezone(pytz.utc)
        expired = expire_time <= now
        css_class = "link expired" if expired else "link"
        f.write(f'<div class="{css_class}">')
        f.write(f'<div><strong>{link["name"]}</strong></div>')
        f.write(f'<div class="meta">Expires at: {expire_time.strftime("%Y-%m-%d %H:%M:%S %Z")}</div>')
        if not expired:
            f.write(f'<div><a href="{link["url"]}">{link["url"]}</a></div>')
        f.write('</div>')
    f.write("</body></html>")
